'use strict';

var env = process.env.NODE_ENV || 'onprem';

module.exports = {
  env: env,
  mulesoftOrganizationId: 1,
  minAmountOfVotesNeededToBeShown: 2,
  ratingReferenceValue: 2.5,
  studioVersionSupportingHostPath: '5.0.0',
  ignoreObjectAmountLimit: true,
  database: {
    host: 'exchangedb',
    name: 'postgres',
    user: 'postgres',
    password: ''
  },
  sitemapBaseURL: '',
  hostname: '',
  suffixHostPath: '/exchange',
  shareUrlSuffixHostPath: '/exchange',
  supportHttps: true,
  segmentioKey: '',
  mulesoftAnalyticsId: '',
  isAnalyticsEnabled: false,
  coreServicesDirect: {
    baseURL: 'http://authentication:3004'
  },
  coreServices: {
    baseURL: '/accounts',
    clientId: 'library',
    signinPath: '/oauth2/authorize',
    signoutPath: '/api/logout'
  },
  newRelic: {
    enabled: false
  }
};
