'use strict';

var path = require('path');
var root = path.normalize(__dirname + '/../..');

module.exports = {
  urls: {
    api_platform: {
      api: {
        base: 'http://nginx/apiplatform'
      }
    },

    cloudhub : {
      base : 'http://nginx/hybrid'
    }
  },

  database: {
    connection: {
      host:     'authdb',
      user:     'postgres',
      password: '',
      database : 'postgres'
    }
  },

  session : {
    secret: 'defaultSessionSecret'
  },

  crypto : {
    password : 'defaultClientSecretEncryption',
    orgProperty: {
      password: 'defaultOrgPropertyEncryption'
    },
    clientSecret: {
      password: 'defaultClientSecretEncryption'
    },
    accessToken: {
      password: 'defaultAccessTokenEncryption'
    }
  },

  auth : {
    saml_private_pem : path.join(root, 'api/config/ssl/key.pem')
  },

  https : {
    enabled : false
  },

  adminUI: {
    view: false
  },

  cloudhub: {
    notifyOfSignups: false,
    view: true,
    validateWorkers: false,
    service: './services/cloudhub_service_mock'
  },

  exchange: {
    view: true
  },

  support: {
    view: false
  },

  features: {
    setup: true
  },

  audit_logging: {
    enabled: false
  },

  environments: {
    deleteRequests: [
      {'Applications': 'http://nginx/hybrid/api/v1/admin/servers?orgId={{organization}}&envId={{environment}}'}
    ],

    roleGroups: [{
      name: 'Application Admin (%s)',
      description: 'Application (%s) Admin users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1', // Read Applications
        '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf', // Create Applications
        '4b3b5050-2f33-4740-9b63-dccc421b9f92', // Delete Applications
        '4e2a978e-0c79-4131-bebf-a653fd8ba039', // Download Applications
        '4db01de7-89db-473e-8591-606204e9baab', // Manage Settings
        '8b7caaba-e94a-11e4-b02c-1681e6b88ec1', // Read Servers
        '53823f29-6e57-4c42-acdb-e42a881a888f'  // Manage Servers
      ],
      isCloudhubAdmin: true
    }, {
      name: 'Appication Developer (%s)',
      description: 'Application (%s) Developer users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1', // Read Applications
        '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf', // Create Applications
        '4e2a978e-0c79-4131-bebf-a653fd8ba039', // Download Applications
        '4db01de7-89db-473e-8591-606204e9baab', // Manage Settings
        '8b7caaba-e94a-11e4-b02c-1681e6b88ec1'  // Read Servers
      ]
    }, {
      name: 'Application Support (%s)',
      description: 'Application (%s) Support users',
      roles: [
        '674c9f7a-ee81-44d7-b25f-eb938d8e69b1' // Read Applications
      ]
    }]
  },

  organizations: {
    deleteRequests : [
      {'Applications': 'http://nginx/hybrid/api/v1/admin/servers?orgId={{organization}}'},
      {'API Platform': 'http://nginx/apiplatform/repository/v2/organizations/{{organization}}'}
    ],

    entitlements: {
      createEnvironments: true,
      createSubOrgs:      true,
      globalDeployment:   false,
      hybrid: {
        enabled: true
      },
      vCoresProduction: {
        assigned:   0,
        reassigned: 0
      },
      vCoresSandbox: {
        assigned:   0,
        reassigned: 0
      },
      staticIps: {
        assigned: 0,
        reassigned: 0
      },
      workerLoggingOverride: {
        enabled: false
      }
    },

    subscription: {
      type: 'Anypoint Platform - On-Premises Edition',
      expiration: 365
    },

    roleGroups: {
      master: [
        {
          name: 'Organization Administrators',
          description: 'Organization Administrators',
          roles: ['d74ef94a-4292-4896-b860-b05bd7f90d6d', '674c9f7a-ee81-44d7-b25f-eb938d8ebaa1', 'ceeabcd5-eb31-41c9-b387-01a0e9095620', 'bc402b36-438d-430d-88c1-b2a14726a863']
        },
        {
          name: 'API Creators',
          description: 'API Creators',
          roles: ['4b8c4ccd-c8fd-49ff-aa97-cf434d9d4e97']
        },
        {
          name: 'API Versions Owner',
          description: 'Owner of all API versions in the organization',
          roles: ['93eb1453-8f84-4fff-8a83-7c1ac7d2814b']
        },
        {
          name: 'Portals Viewer',
          description: 'Viewer of all portals in the organization',
          roles: ['16beef43-7aa3-497a-b372-c0e6fb2d8bd1']
        },
        {
          name: 'Exchange Administrators',
          description: 'Exchange Administrators',
          roles: ['bc402b36-438d-430d-88c1-b2a14726a863']
        },
        {
          name: 'Exchange Contributors',
          description: 'Exchange Contributors',
          roles: ['d5b3fd8a-abe9-48de-a4e1-01040ca99b2e']
        }
      ],

      subOrg: [
        {
          name: 'Organization Administrators',
          description: 'Organization Administrators',
          roles: ['d74ef94a-4292-4896-b860-b05bd7f90d6d', '674c9f7a-ee81-44d7-b25f-eb938d8ebaa1', 'ceeabcd5-eb31-41c9-b387-01a0e9095620']
        },
        {
          name: 'API Creators',
          description: 'API Creators',
          roles: ['4b8c4ccd-c8fd-49ff-aa97-cf434d9d4e97']
        },
        {
          name: 'API Versions Owner',
          description: 'Owner of all API versions in the Business Group',
          roles: ['93eb1453-8f84-4fff-8a83-7c1ac7d2814b']
        },
        {
          name: 'Portals Viewer',
          description: 'Viewer of all portals in the Business Group',
          roles: ['16beef43-7aa3-497a-b372-c0e6fb2d8bd1']
        }
      ]
    }
  },

  cloudhubRoles : {
    shared : [
      {
        id: '3c91e5ca-fe58-441f-b6ab-a2be0a684bbf',
        name: 'Create Applications'
      },
      {
        id: '4b3b5050-2f33-4740-9b63-dccc421b9f92',
        name: 'Delete Applications'
      },
      {
        id: '4e2a978e-0c79-4131-bebf-a653fd8ba039',
        name: 'Download Applications'
      },
      {
        id: '4db01de7-89db-473e-8591-606204e9baab',
        name: 'Manage Settings'
      },
      {
        id: '674c9f7a-ee81-44d7-b25f-eb938d8e69b1',
        name: 'Read Applications'
      }
    ],
    hybridOnly : [
      {
        id: '8b7caaba-e94a-11e4-b02c-1681e6b88ec1',
        name: 'Read Servers'
      },
      {
        id: '53823f29-6e57-4c42-acdb-e42a881a888f',
        name: 'Manage Servers'
      }
    ]
  },
  
  secrets: {
    cloudhub_secret : 'defaultApplicationsSecret',
    apiportal_secret : 'defaultApiportalSecret',
    analytics_secret : 'defaultAnalyticsSecret',
    analytics_migrator_secret : 'defaultAnalyticsMigratorSecret',
    coreservices_client_secret : 'defaultCoreservicesClientSecret',
    datagateway_secret: 'defaultDatagatewaySecret',
    studio_secret: 'studio123',
    library_secret: 'defaultLibrarySecret',
    messaging_secret: 'defaultMessagingSecret',
    hybrid_secret: 'defaultHybridSecret',
    'api-platform-web_secret': 'defaultApiPlatformWebSecret',
    platformMessagesApi_secret: 'defaultPlatformMessagesApiSecret',
    platformMessagesProcessor_secret: 'defaultPlatformMessagesProcessorSecret'
  },

  tokens: {
    messaging_token: 'defaultMessagingToken',
    apiportal_token: 'defaultApiportalToken',
    'api-platform-web_token': 'defaultApiPlatformWebToken',
    platformMessagesApi_token: 'defaultPlatformMessagesApiToken',
    platformMessagesProcessor_token: 'defaultPlatformMessagesProcessorToken'
  }
};
