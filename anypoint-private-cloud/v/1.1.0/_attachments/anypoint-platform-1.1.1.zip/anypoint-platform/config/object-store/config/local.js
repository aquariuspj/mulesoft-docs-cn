'use strict';

module.exports = {
  knex: {
    debug:      false,
    client:     'pg',
    connection: {
      host:     'objectstoredb',
      user:     'object_store',
      password: 'object_store',
      database: 'object_store',
      charset:  'utf8'
    }
  },

  storage: {
    path: '/usr/share/object_store'
  }
};
